﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public abstract class Info1
{
    private string _fname;
    private string _lname;
    private char _mname;
    private char _gender;

    public string fname { get { return _fname; } set { _fname = value; } }
    public string lname
    {
        get { return _lname; }
        set { _lname = value; }
    }
    public char mname { get { return _mname; } set { _mname = value; } }
    public char gender { get { return _gender; } set { _gender = value; } }

    public abstract void DisplayInfo();
}

public class Driverinfo : Info1
{
    private string _address;
    private string _licensenumber;
    private int _age;
    public int DriverID { get; set; }
    public string address { get { return _address; } set { _address = value; } }
    public string licensenumber
    {
        get { return _licensenumber; }
        set { _licensenumber = value; }
    }
    public int age { get { return _age; } set { _age = value; } }

    public override void DisplayInfo()
    {
        Console.WriteLine($"{lname}\t\t{fname}\t\t{mname}\t\t{age}\t{gender}\t{address}\t\t{licensenumber}\n");
    }
}

public class PassengerInfo : Info1
{
    private char _minitial;
    public char minitial { get { return _minitial; } set { _minitial = value; } }
    public override void DisplayInfo()
    {
        Console.WriteLine($"{lname}\t\t{fname}\t\t{minitial}. \t{gender}");
    }
}
